import java.util.Scanner;

public class DrinkingAge {
	public static void main(String[]args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Welcome User");
		System.out.println("Enter Age to verify legal drinking age");
		int userSelection = input.nextInt();
		if(userSelection >=21)
			System.out.println("Legal Drinking Age");

		if(userSelection < 21)
			System.out.println("Not legal to Drink");
	}


}
